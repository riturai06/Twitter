export class ApiResponse {

    status: any;
    message: any;
    result: any;
  }