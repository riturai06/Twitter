package com.tweeter.fse.controller;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweeter.controller.TwitterController;
import com.tweeter.dto.ApplicationUser;
import com.tweeter.dto.ReplyEntity;
import com.tweeter.dto.TweetResponse;
import com.tweeter.model.Reply;
import com.tweeter.repository.ReplyRepository;
import com.tweeter.serviceImplementation.TweetServiceImpl;;

@ExtendWith(MockitoExtension.class)
public class TweetControllerTest {
	
	private MockMvc mockMvc;
	
	@Mock
	private TweetServiceImpl tweetServiceMock = new TweetServiceImpl();
	
	@Mock
	private ReplyRepository replyRepository;
	
	@InjectMocks
	private TwitterController tweetController;
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(tweetController).build();
		
		
	}

	@Test
	public void postTweetPositiveTest() throws Exception
	{
		String reqJson="{\"tweetDesc\":\"desc\",\"emailId\":\"fse@gmail.com\"}";
		String url = "/api/v1.0/tweets/posttweet";
		
		String responseJson="Success";
		
		when(tweetServiceMock.postTweet(Mockito.any())).thenReturn("Success");
		MockHttpServletResponse response = mockMvc
				.perform(post(url).accept(MediaType.APPLICATION_JSON).content(reqJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals(responseJson, response.getContentAsString());
	}
	
	
	@Test
	public void postReplyPositiveTest() throws Exception
	{
		String reqJson="{\"replyDesc\":\"desc\",\"emailId\":\"fse@gmail.com\",\"tweetId\":\"1\"}";
		String url = "/api/v1.0/tweets/replyTweet";
		
		String responseJson="Success";
		
		when(tweetServiceMock.postReply(Mockito.any())).thenReturn("Success");
		MockHttpServletResponse response = mockMvc
				.perform(post(url).accept(MediaType.APPLICATION_JSON).content(reqJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals(responseJson, response.getContentAsString());
	}
	
	
	@Test
	public void deletTweetPostiveFlow() throws Exception{
		String url="/api/v1.0/tweets/deleteTweet/1";
		
		String expectedJson="Success";
		when(tweetServiceMock.deleteTweet(1)).thenReturn("Success");
		MockHttpServletResponse response = mockMvc.perform(delete(url).accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		assertEquals(expectedJson, response.getContentAsString());
		
		
		
	}
	
	
	
}
