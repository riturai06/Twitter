package com.tweeter.fse.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;

import com.tweeter.dto.ApplicationUser;
import com.tweeter.dto.ReplyEntity;
import com.tweeter.dto.TweetRequest;
import com.tweeter.dto.TweetResponse;
import com.tweeter.model.Reply;
import com.tweeter.model.Tweet;
import com.tweeter.repository.ReplyRepository;
import com.tweeter.repository.TweetRepository;
import com.tweeter.repository.UserRepository;
import com.tweeter.serviceImplementation.TweetServiceImpl;



public class TweetServiceImplTest {
	
	private MockMvc mockMvc;
	
	@Mock
	private UserRepository userrepo;
	
	
	@Mock
	private TweetRepository tweetRepo;
	
	@Mock
	private ReplyRepository replyRepo;
	
	@InjectMocks
	private TweetServiceImpl twitterServiceMock=new TweetServiceImpl();
	
	@BeforeEach
	public void setup() {

		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void postTweetPositiveTest() throws Exception {
		
		TweetRequest tweetRequest=new TweetRequest();
		tweetRequest.setEmail("fse@gmail.com");
		tweetRequest.setTweetDesc("Desc");
		tweetRequest.setTweetTag("tag");
		
		ApplicationUser register = new ApplicationUser();
		register.setEmail("fse@gmail.com");
		
		String expected="Success";
		
		when(tweetRepo.findByRecordActive('Y')).thenReturn(null);
		
		
		when(userrepo.findByEmail("fse@gmail.com")).thenReturn(register);
		
		String actualresp=twitterServiceMock.postTweet(tweetRequest);
		
		assertEquals(expected,actualresp);
		
	
	}
	
	@Test
	public void postTweetElseTest() throws Exception {
		
		TweetRequest tweetRequest=new TweetRequest();
		tweetRequest.setEmail("ritu@gmail.com");
		tweetRequest.setTweetDesc("TweetTest");		
		ApplicationUser register = new ApplicationUser();
		register.setEmail("ritu@gmail.com");
		
		List<Tweet> tweetList = new ArrayList<>();
		
		Tweet tweet = new Tweet();
		tweet.setEmail("ritu@gmail.com");
		tweet.setTweetId(1);
		tweet.setTweetDescription("TweetTest");
		tweetList.add(tweet);
		
		
		String expected="Success";
		
		when(tweetRepo.findByRecordActive('Y')).thenReturn(tweetList);
		
		
		when(userrepo.findByEmail("ritu@gmail.com")).thenReturn(register);
		
		String actualresp=twitterServiceMock.postTweet(tweetRequest);
		
		assertEquals(expected,actualresp);
		
	
	}
	
	@Test
	public void getAllTweetsPostiveTest() throws Exception{
		
		List<Tweet> tweetList = new ArrayList<>();
		
		Tweet tweet = new Tweet();
		tweet.setEmail("ritu@gmail.com");
		tweet.setTweetId(1);
		tweet.setTweetDescription("TweetDesc");
		tweet.setDate("");
		tweetList.add(tweet);
		
		List<Reply> replyList=new ArrayList<>();
		
		Reply reply = new Reply();
		reply.setEmail("ritu@gmail.com");
		reply.setReplyDesc("Tweet");
		reply.setTweetId(1);
		reply.setDate("");
		
		replyList.add(reply);
		
		List<TweetResponse> expectedList= new ArrayList<>();
		TweetResponse expected =new TweetResponse();
		expected.setDate("");
		expected.setTweetBy("ritu@gmail.com");
		expected.setTweetDesc("TweetDesc");
		expected.setTweetId(1);
		
		List<ReplyEntity> replyDTOList = new ArrayList<>();
		ReplyEntity replyDTO=new ReplyEntity();
		replyDTO.setEmail("ritu@gmail.com");
		replyDTO.setReplyDesc("Tweet");
		replyDTO.setTweetId(1);
		replyDTO.setDate("");
		replyDTOList.add(replyDTO);
		
		expected.setReplyList(replyDTOList);
		
		expectedList.add(expected);
		
		
		
		when(tweetRepo.findByRecordActive('Y')).thenReturn(tweetList);
		
		when(replyRepo.findByTweetId(1)).thenReturn(replyList);
		
		List<TweetResponse> actualresp=twitterServiceMock.getAllTweets(null);
		
		assertEquals(expectedList,actualresp);
	}
	
	@Test
	public void postReplyPositiveTest() throws Exception{
		
		ReplyEntity replyDTO = new ReplyEntity();
		replyDTO.setEmail("ritu@gmail.com");
		replyDTO.setReplyDesc("Tweet");
		replyDTO.setTweetId(1);
		
		String actualresp=twitterServiceMock.postReply(replyDTO);
		
		assertEquals("Success",actualresp);
		
	}


}
