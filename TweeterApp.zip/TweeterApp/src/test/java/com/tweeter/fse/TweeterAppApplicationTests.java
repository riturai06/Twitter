package com.tweeter.fse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TweeterAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
