package com.tweeter.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweeter.model.Reply;

public interface ReplyRepository extends MongoRepository<Reply,Integer> {
	
	List<Reply> findByTweetId(int tweetId);

}
