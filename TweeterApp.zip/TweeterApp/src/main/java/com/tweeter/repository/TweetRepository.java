package com.tweeter.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;

import com.tweeter.dto.TweetRequest;
import com.tweeter.model.Tweet;

public interface TweetRepository extends MongoRepository<Tweet, Integer> {

	public List<Tweet> findByRecordActive(char recordActive);

	public List<Tweet> findByEmail(String email);
	

}
