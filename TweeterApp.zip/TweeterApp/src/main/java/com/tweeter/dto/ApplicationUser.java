package com.tweeter.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.tweeter.model.Tweet;

@Component
@Document
public class ApplicationUser implements Serializable {
	@Id
	
	private Integer id;
	
	private String firstName;
	
	private String lastName;
	
	private String gender;
	
	private String email;
	
	private String password;
	
	private String confirmPassword;
	
	private List<Tweet> tweet;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public String setPassword(String password) {
		return this.password = password;
	}


	public List<Tweet> getTweet() {
		return tweet;
	}

	public void setTweet(List<Tweet> tweet) {
		this.tweet = tweet;
	}

	public ApplicationUser() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	@Override
	public String toString() {
		return "ApplicationUser [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", gender="
				+ gender + ", email=" + email + ", password=" + password + ", confirmPassword=" + confirmPassword
				+ ", tweet=" + tweet + "]";
	}

	public ApplicationUser(Integer id, String firstName, String lastName, String gender, String email, String password,
			String confirmPassword, List<Tweet> tweet) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.email = email;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.tweet = tweet;
	}
	
	
	
	

}
