package com.tweeter.model;


import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@Document
public class Tweet {
	
	@Id
	private int tweetId;
	
	private String tweetDescription;
	
	private String tweetTag;
	
	private String Date;
	
	private String email;
	
	private char recordActive;
	
	private List<Reply> reply;

	public void setReply(List<Reply> reply) {
		this.reply = reply;
	}

	public List<Reply> getReply() {
		return reply;
	}

	public int getTweetId() {
		return tweetId;
	}

	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}

	public String getTweetDescription() {
		return tweetDescription;
	}

	public void setTweetDescription(String tweetDescription) {
		this.tweetDescription = tweetDescription;
	}

	public String getTweetTag() {
		return tweetTag;
	}

	public void setTweetTag(String tweetTag) {
		this.tweetTag = tweetTag;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public char getRecordActive() {
		return recordActive;
	}

	public void setRecordActive(char recordActive) {
		this.recordActive = recordActive;
	}

	@Override
	public String toString() {
		return "Tweet [tweetId=" + tweetId + ", tweetDescription=" + tweetDescription + ", tweetTag=" + tweetTag + ", Date="
				+ Date + ", email=" + email + ", recordActive=" + recordActive + ", reply=" + reply
				+ "]";
	}

	public Tweet(int tweetId, String tweetDescription, String tweetTag, String date, String email, char recordActive,
			List<Reply> reply) {
		super();
		this.tweetId = tweetId;
		this.tweetDescription = tweetDescription;
		this.tweetTag = tweetTag;
		Date = date;
		this.email = email;
		this.recordActive = recordActive;
		this.reply = reply;
	}

	public Tweet() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	

	
	

	

}
