package com.tweeter.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.stereotype.Component;

@Component
@Document(collection = "reply")
public class Reply {
	
    private int replyId;
    
	private String email;
	
	private int tweetId;
	
	private String replyDesc;
	
	private String date;
	
	public int getReplyId() {
		return replyId;
	}

	public void setReplyId(int replyId) {
		this.replyId = replyId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReplyDesc() {
		return replyDesc;
	}

	public void setReplyDesc(String replyDesc) {
		this.replyDesc = replyDesc;
	}

	public int getTweetId() {
		return tweetId;
	}

	public void setTweetId(int tweetId) {
		this.tweetId = tweetId;
	}
	
	

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Reply [replyId=" + replyId + ", email=" + email + ", tweetId=" + tweetId + ", replyDesc=" + replyDesc
				+ ", date=" + date + "]";
	}

	public Reply(int replyId, String email, int tweetId, String replyDesc, String date) {
		super();
		this.replyId = replyId;
		this.email = email;
		this.tweetId = tweetId;
		this.replyDesc = replyDesc;
		this.date = date;
	}

	public Reply() {
		// TODO Auto-generated constructor stub
	}



	
	
	
	
	
	
	
	
	

}
